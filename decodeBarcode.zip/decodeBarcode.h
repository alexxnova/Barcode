#ifndef decodeBarcode_H_
#define decodeBarcode_H_
#include "validation.h"

char * readScannerSignal(char * fileName);
char * decodeRawSignal(char * rawSignal);
int decodeSignal(char * signal);
char reverseString(char *string);
//char * reverseSignal(char * string, char * reverse);
int roundNo(float num);
int printResult(int numSymbols, int weight[]);

#endif